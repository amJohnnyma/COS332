public class Prac_1_Right {
    public static void main(String[] args) {
        System.out.println("<!DOCTYPE html><head><title></title></head><body>"); 
        System.out.println("<h6 style=\"background-color:green; width: 40%; padding:20px\">You chose RIGHT</h6>"); 
        System.out.println("<p><a href=\"/cgi-bin/Prac_1.cgi\">Try again</a></p>");
        System.out.println("</body></html>"); 
    }
}
