
public class Prac_1_Wrong {
    public static void main(String[] args) {
        System.out.println("<html><body>"); 
        System.out.println("<h6 lass=\"background-color:red; width: 40%; padding:20px\">You chose WRONG</h6>"); 
        System.out.println("</body></html>"); 
    }
}
