#!/usr/bin/perl
use strict;
use warnings;
use CGI;

# Create a new CGI instance
my $cgi = CGI->new;
print $cgi->header('text/html');

#!/usr/bin/perl
use strict;
use warnings;
use CGI;

my $q = CGI->new;
print "Content-type: text/html\n\n";

# Store the current expression using a temporary file (simple state management)
my $file = "/tmp/calc_state.txt";
my $expression = "";

if (-e $file) {
    open(my $fh, '<', $file);
    $expression = <$fh>;
    close($fh);
    chomp $expression;
}

# Get input from query string
my $input = $q->param('input') // '';

# Process input
if ($input eq "C") {
    $expression = "";  # Clear expression
} elsif ($input eq "=") {
    $expression = eval($expression) // "Error";  # Evaluate expression
} else {
    $expression .= $input;  # Append input
}

# Save updated expression
open(my $fh, '>', $file);
print $fh $expression;
close($fh);

# Return updated page
print <<END;
<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.tailwindcss.com"></script>
    <title>Prac 3</title>
</head>
<body class="flex justify-center items-center">
<div class="bg-gray-200 h-[60vh] w-[50vw] rounded-lg p-8 m-0">
    <p id="expression" class="bg-white w-[40vw] h-[10%] flex justify-center items-center">$expression</p>

    <div class="w-[50vw] h-[90%] flex-col">
	<div class="w-[50vw] flex-row justify-center items-center">
            <a href="/cgi-bin/calc.pl?input=1">1</a>
	    <a href="/cgi-bin/calc.pl?input=2">2</a>
	    <a href="/cgi-bin/calc.pl?input=3">3</a>
	    <a href="/cgi-bin/calc.pl?input=4">4</a>
            <a href="/cgi-bin/calc.pl?input=5">5</a>
	</div>
        <div class="w-[50vw] flex-row justify-center items-center">
	    <a href="/cgi-bin/calc.pl?input=6">6</a>
	    <a href="/cgi-bin/calc.pl?input=7">7</a>
	    <a href="/cgi-bin/calc.pl?input=8">8</a>
	    <a href="/cgi-bin/calc.pl?input=9">9</a>
	    <a href="/cgi-bin/calc.pl?input=0">0</a>
	</div>
        <div class="w-[50vw] flex-row justify-center items-center">
	    <a href="/cgi-bin/calc.pl?input=%2B">+</a>
	    <a href="/cgi-bin/calc.pl?input=%2D">-</a>
	    <a href="/cgi-bin/calc.pl?input=%2A">*</a>
	    <a href="/cgi-bin/calc.pl?input=%2F">/</a>

	    <p><a href="/cgi-bin/calc.pl?input==">=</a></p>
	</div>
	<div class="w-[50vw] flex-row justify-center items-center">	
	    <p><a href="/cgi-bin/calc.pl?input=C">Clear</a></p>
	</div>
    </div>
</div>
</body>
</html>
END
