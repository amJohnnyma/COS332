public class Prac_1_Right {
    public static void main(String[] args) {
	System.out.println("Content-Type: text/html\n");
        System.out.println("<html><body>"); 
        System.out.println("<h6 style=\"background-color:green; width: 40%; padding:20px\">You chose RIGHT</h6>"); 
        System.out.println("</body></html>"); 
    }
}
